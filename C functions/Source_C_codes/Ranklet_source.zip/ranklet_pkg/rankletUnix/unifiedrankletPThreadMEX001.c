/* 
 * Paralell Ranklets Adapted to work with MATLAB - MEX datatypes
 * 
 * Base algorithm: Distribution counting based on quicksort - midranks - CPU threads
 * Splits the working load in CPU threads
 * Use of individual cell operations to allow easy optimization by the compiler and helps the implementations of multiple threads (CPU-GPU)
 * 2014 
 * WARNING: The maximum window size is 64, the maximum window midsize size is 32, and the number of threads used to split the load is 32
 * 
 * To improve the perfomance using the gcc compiler, backup the gccopts.sh script found in MATLAB/bin/gccopts.sh and then set:
 * ---------------------------------
 * COPTIMFLAGS='-O3 -DNDEBUG'
 * CDEBUGFLAGS=' '
 * ---------------------------------
 * which means, disable all debug flags and set the max optimization level.
 * Then refresh the mex script by applying the command:
 * mex -setup 
 * (choose option 1)
 * 
 * Compile: mex unifiedrankletPThreadMEX001.c
 * Call: [H V D]=unifiedrankletPThreadMEX001(I,windowMZ);
 * H->HORIZONTAL_RANKLET 
 * V->VERTICAL_RANKLET 
 * D->DIAGONAL_RANKLET
 * I->Original image uint8
 * windowMZ-> window midsize
 * 
 */

#include "mex.h"
#include <pthread.h>
#include <math.h>
#include <unistd.h>

/* #include <stdio.h> */
/* #include <stdlib.h> */
/* #include <string.h> */
/* #include <time.h> */
/* #include <sys/times.h> */


/* Number of threads in which will be split the ranklet */
#define NUMBEROFTHREADS 32
/* Maximum area covered by a ranklet window 
 * it means a midSizeWindow of 16px or a windowSize of 32px  * 
 */
#define MAXWINAREA 4096
/* Image type - will be cast to int */
typedef unsigned char IMAGETYPE;

/**************************************************/
/* prototypes */
void *rankletThread(void *myRankletThreadIndex);
void matrixRankletAtomic(IMAGETYPE* A, double * HORIZMAT, double * VERTMAT, double * DIAGMAT, int M, int N, int windowMZ);
void pixelRankletAtomic(IMAGETYPE* A, double * HORIZMAT, double * VERTMAT, double * DIAGMAT, int M, int N, int windowMZ, int npoints, int npointsSquare, int posOX, int poxOY);

void computeHalFranks(int npoints, int * pixelBuffer, int * pixelIndexBuffer, double * halfRanks);
void quickSort(int *arr, int elements, int *keys);

/**************************************************/
/* main function defined to test the ranklet in c */

int main(void){
     srand ( (unsigned)time ( NULL ) );
     int pixelBuffer [MAXWINAREA];
     int pixelIndexBuffer [MAXWINAREA];     
     int pixelBufferBack [MAXWINAREA];
     int pixelIndexBufferBack [MAXWINAREA];     
     int pixelRefOX [MAXWINAREA];
     int pixelRefOY [MAXWINAREA];
     double halfRanks [MAXWINAREA];
     double halfRanksBack [MAXWINAREA];     
     int i;
     int elements=11;
      /*
      for (i=0;i<elements-1;i=i+2){
        pixelBuffer[i]=i;
        pixelBuffer[i+1]=i;
        pixelIndexBuffer[i]=i;
        pixelIndexBuffer[i+1]=i+1;
      }
        pixelBuffer[elements-1]=i+1;
        pixelIndexBuffer[elements-1]=i;*/	
      for(i=0;i<elements;i++){
	pixelBuffer[i]=rand()%16;
	pixelBufferBack[i]=pixelBuffer[i];
	pixelIndexBuffer[i]=i;
	pixelIndexBufferBack[i]=i;
      }
     printf("original pixels \n");
     for (i=0;i<elements;i++)       
     printf("%i, ", pixelBuffer[i]);
     printf("\n");
     printf("original index of pixels \n");
     for (i=0;i<elements;i++)       
     printf("%i, ", pixelIndexBuffer[i]);
     printf("\n");     
     
     quickSort(&pixelBuffer[0], elements, &pixelIndexBuffer[0]);
     computeHalFranks(elements, &pixelBuffer[0], &pixelIndexBuffer[0], &halfRanks[0]);
     
     printf("pixel buffer ordered elemnts \n");
     for (i=0;i<elements;i++)
       printf("%i, ",pixelBuffer[i]);
     printf("\n");     
     printf("pixel buffer index \n");
     for (i=0;i<elements;i++)
       printf("%i, ",pixelIndexBuffer[i]);
     printf("\n");         
     printf("pixel buffer unordered elements \n");
     for (i=0;i<elements;i++)
       printf("%i, ", pixelBuffer[pixelIndexBuffer[i]]);
     printf("\n");              
     printf("pixel halfranks index \n");
     for (i=0;i<elements;i++)
       printf("%f, ", halfRanks[i]);
     printf("\n");    
     
     computeHalFranks(elements, &pixelBuffer[0], &pixelIndexBuffer[0],  &halfRanks[0]);
     printf("pixel halfranks index \n");
     for (i=0;i<elements;i++)
       printf("%f, ", halfRanks[i]);
     printf("\n");
   return 1;
}


#define IS_REAL_2D_FULL_SINGLE(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P) == 2 && !mxIsSparse(P) && !mxIsDouble(P))
#define IS_REAL_2D_FULL_DOUBLE(P) (!mxIsComplex(P) && mxGetNumberOfDimensions(P) == 2 && !mxIsSparse(P) && mxIsDouble(P))
#define IS_REAL_SCALAR(P) (IS_REAL_2D_FULL_DOUBLE(P) && mxGetNumberOfElements(P) == 1)

double *HORIZMAT, *DIAGMAT, *VERTMAT, p, colnorm;
unsigned char *A;
int windowMZ; /* window midsize, which is the same for X and Y */
int M,N;
int npoints;
int npointsSquare;

int myActivityCells[NUMBEROFTHREADS][2];
pthread_t myThreads[NUMBEROFTHREADS];
void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ){
  /* mexPrintf("mexFunction -> ranklets begins working"); */
  /* Macros for the output and input arguments */
  #define HORIZ_OUT plhs[0] /* Horizontal ranklets */
  #define VERT_OUT plhs[1] /* Horizontal ranklets */
  #define DIAG_OUT plhs[2] /* Horizontal ranklets */
  
  #define A_IN  prhs[0] /* Matriz de la imagen */
  #define P_IN  prhs[1] /* Tamaño de la ventana a analizar */ 
  
  
  if (nrhs < 1 || nrhs > 2 ) /*Check the number of arguments*/
    mexErrMsgTxt("Wrong number of input parameters");
  else if(nlhs > 3)
    mexErrMsgTxt("Too many output arguments");
  else if(nlhs < 3)
    mexErrMsgTxt("Too few output arguments");
  
  /* if(!IS_REAL_2D_FULL_DOUBLE(A_IN)) */
  if(!IS_REAL_2D_FULL_SINGLE(A_IN))
    mexErrMsgTxt("First argument must be a uint8 2D full double array");
  
  if(nrhs == 1) /* If p (the midsize of the window is un-specified, the we set it to 1) */
    p=1;
  else
    if (!IS_REAL_SCALAR(P_IN))
      mexErrMsgTxt("The second argument, the midsize window, must be a real double scalar");
    else
      p=mxGetScalar(P_IN);
    
    M = mxGetM (A_IN); /* Number of columns - x -  of A */    
    N = mxGetN (A_IN); /* Number of rows - x -  of A */    
    A = (unsigned char *)mxGetData (A_IN); /* Getting the pointer to A como uint8, o entero positivo de 8 bits*/
    HORIZ_OUT = mxCreateDoubleMatrix (M,N,mxREAL);
    VERT_OUT = mxCreateDoubleMatrix (M,N,mxREAL);
    DIAG_OUT = mxCreateDoubleMatrix (M,N,mxREAL);
    
    HORIZMAT = mxGetPr (HORIZ_OUT);  /* Getting the pointer to the horizontal ranklet */
    VERTMAT = mxGetPr (VERT_OUT);    /* Getting the pointer to the vertical ranklet */ 
    DIAGMAT = mxGetPr (DIAG_OUT);    /* Getting the pointer to the diagonal ranklet */ 
    windowMZ=(int)p;     /* Setting the window midsize */   
    npoints=windowMZ*windowMZ*4;
    npointsSquare=npoints*npoints;    
    /*THIS IS ONLY A TEST TO RETURN THE ORIGINAL MATRIX - FULL RANKLET VERSION IS STILL IN PROCESS*/
    /* trought the rows  trought the columns  */
    /* because A is unsigned char we must do a cast */
    
    /*for(n=0; n<N; n++){ 
      for(m=0; m<M; m++){ 
	B[m + M*n]=(double) A[m + M*n]; 
      }
    }*/
    
    /* split the ranklet cell between all the threads */
    int rankletCells=(M-((windowMZ-1)+(windowMZ-2)))*(N-((windowMZ-1)+(windowMZ-2)));
    int numberOfCells;
    int remainings;
    int offset;
    int m;
    numberOfCells=floor(rankletCells/NUMBEROFTHREADS);
    remainings=rankletCells%NUMBEROFTHREADS;
    offset=0;
    /*for(m=0;m<NUMBEROFTHREADS;m++){
      myActivityCells[m][0]=numberOfCells*m+(offset);
      if(offset<remainings){
	offset++;
	myActivityCells[m][1]=numberOfCells*(m+1)+(offset);
      }else{
        myActivityCells[m][1]=numberOfCells*(m+1)+(offset);
      }      
    }*/
    
    /* now launch all threads */
    int myThreadsIndex [NUMBEROFTHREADS];
    int tCode=0;
    for(m=0;m<NUMBEROFTHREADS;m++){
     myActivityCells[m][0]=numberOfCells*m+(offset);
      if(offset<remainings){
	offset++;
	myActivityCells[m][1]=numberOfCells*(m+1)+(offset);
      }else{
        myActivityCells[m][1]=numberOfCells*(m+1)+(offset);
      }  
     myThreadsIndex[m]=m;
     tCode=pthread_create(&myThreads[m], NULL, rankletThread, &myThreadsIndex[m]);
     if (tCode){
       fprintf(stderr,"Error - pthread_create() return code: %d\n",tCode);
       mexErrMsgTxt("Error - pthread_create()");
     }     
    }
    
    /* and wait until all of them finish the work */
    for(m=0;m<NUMBEROFTHREADS;m++){
      pthread_join(myThreads[m], NULL);
    }
  /* matrixRankletAtomic(&A[0], &HORIZMAT[0], &VERTMAT[0], &DIAGMAT[0], M, N, windowMZ); */
  
  return;
}
/* Function to compute the ranklets (horizontal, vertical and diagonal) of an image in a single function, non dependendant of global variables
 * Just use the matrix of original image as input and the matrix of the ranklets as outputs
 * IMAGETYPE* A - original image in vector
 * double * HORIZMAT - horizRankletMatrix in vector
 * double * VERTMAT - vertRankletMatrix in vector
 * double * DIAGMAT - diagonalRankletMatrix in vector
 * M - number of columns
 * N - number of rows
 */
void matrixRankletAtomic(IMAGETYPE* A, double * HORIZMAT, double * VERTMAT, double * DIAGMAT, int M, int N, int windowMZ){
  int m,n;
   for (n=windowMZ; n < (N-(windowMZ-1)) ; n++){
       for (m=windowMZ; m < (M-(windowMZ-1)) ; m++){
         /* HORIZMAT[m + M*n]=(double) A[m + M*n]; */ 
	  pixelRankletAtomic(&A[0], &HORIZMAT[0], &VERTMAT[0], &DIAGMAT[0], M, N, windowMZ,npoints,npointsSquare,m, n); 
       }
    } 
}

void *rankletThread(void *myRankletThreadIndex){
  int * myIndex=(int *)myRankletThreadIndex;  
  int m=0,n=0,i=0;
  for (n=windowMZ; n < (N-(windowMZ-1)) ; n++){
       for (m=windowMZ; m < (M-(windowMZ-1)) ; m++){
	 if (i>=myActivityCells[*myIndex][0]&&i<myActivityCells[*myIndex][1]){ /* compute only my designed cells */
	   /* HORIZMAT[m + M*n]=(double) A[m + M*n];
	   VERTMAT[m + M*n]=(double) A[m + M*n];
	   DIAGMAT[m + M*n]=(double) A[m + M*n];*/
	   pixelRankletAtomic(&A[0], &HORIZMAT[0], &VERTMAT[0], &DIAGMAT[0], M, N, windowMZ,npoints,npointsSquare,m, n); /* and here is why it must be atomic*/
	 }
	 i++;
       }
  }
  return NULL;
}


/*
 * int posOX - column
 * int poxOY - row
 */
void pixelRankletAtomic(IMAGETYPE* A, double * HORIZMAT, double * VERTMAT, double * DIAGMAT, int M, int N, int windowMZ, int npoints, int npointsSquare, int posOX, int posOY){
     int pixelBuffer [MAXWINAREA];
     int pixelIndexBuffer [MAXWINAREA];
     int pixelRefOX [MAXWINAREA];
     int pixelRefOY [MAXWINAREA];
     double halfRanks [MAXWINAREA];
     int i=0, m, n, pixelPos;
     double rkletHORIZ=0.0;     
     double rkletVERT=0.0;
     double rkletDIAG=0.0;
     for (n=posOY-windowMZ; n < posOY+windowMZ ; n++){   /* n - rows */
       for (m=posOX-windowMZ; m < posOX+windowMZ ; m++){ /* m - columns */
	 pixelBuffer[i]=(int) A[m+M*n];
	 pixelIndexBuffer[i]=i;
	 pixelRefOX[i]=0; pixelRefOY[i]=0;
	 pixelRefOX[i]=(int) m-posOX;
	 pixelRefOY[i]=(int) n-posOY;
	 i++;
       }
     }
     /*debugging
      * */    
     /*
      if (npoints!=i){
      printf("npoints=%d, i=%d ", npoints, i);
      mexErrMsgTxt("Not enough npoints \n");
      }*/
     /* mexPrintf(" number of points %d \n", i);  */
     quickSort(&pixelBuffer[0], npoints, &pixelIndexBuffer[0]);              
     /*computehalfranksBasic(npoints, &pixelBuffer[0], &pixelIndexBuffer[0], &halfRanks[0]);*/     
     computeHalFranks(npoints, &pixelBuffer[0], &pixelIndexBuffer[0], &halfRanks[0]); 
     /* debugging */
     /*
     for(m=0;m<npoints-1;m++){
      if(halfRanks[m]>halfRanks[m+1]) mexErrMsgTxt("halfRanksError \n");
      if(pixelBuffer[pixelIndexBuffer[m]]>pixelBuffer[pixelIndexBuffer[m+1]]) mexErrMsgTxt("bad order of pixels magnitud \n");
     }
     */
     /* Compute Mann-Whitney statistics Wxy= Ws -1/2 n (n+1)
     where n is the number of treatment ranks  - see Lehmann,
     Nonparametrics, page 9, Eq. (1.13) */
     /* -npoints*((npoints/2)+1)/4 */
     /* Subtract the average if NORMALIZE is defined */
     /* rklet-=npoints*npoints/8; */     
     /* Compensate for the fact that ranks start from 1 while
     variable i or the halfranks above start from 0 */
     /* rklet+=npoints/2; */     
     double npointsD=(double) npoints;
     double npointsSquareD=(double) npointsSquare;     
     rkletHORIZ = -npointsD*((npointsD/2.0)+1.0)/4.0 - npointsSquareD/8.0 + npointsD/2.0;
     rkletVERT =rkletHORIZ; rkletDIAG=rkletHORIZ;               
     
     for (i=0; i<npoints; i++){       
       /*Normalized ranks*/
       /* get the horizontal ranklet sum */
        if (pixelRefOY[pixelIndexBuffer[i]]<0) rkletHORIZ+=halfRanks[i]; 
       /* get the vertical ranklet sum */
         if (pixelRefOX[pixelIndexBuffer[i]]<0) rkletVERT+=halfRanks[i]; 
       /* get the diagonal ranklet sum */
         if ( ((pixelRefOX[pixelIndexBuffer[i]]<0) && (pixelRefOY[pixelIndexBuffer[i]]<0)) || ((pixelRefOX[pixelIndexBuffer[i]]>=0) && (pixelRefOY[pixelIndexBuffer[i]]>=0)) ) rkletDIAG+=halfRanks[i];      
       
       /* pixelIndexBuffer[i] */
       /* sum of the positions of the subwindow - debugging use only*/
       /*if (pixelRefOY[i]<0) rkletHORIZ+=(double) i;
       if (pixelRefOX[i]<0) rkletVERT+=(double) i;       
       if ( ((pixelRefOX[i]<0) && (pixelRefOY[i]<0)) || ((pixelRefOX[i]>=0) && (pixelRefOY[i]>=0)) ) rkletDIAG+=(double) i;*/       
       /*if (pixelRefOY[i]<0) {rkletHORIZ=rkletHORIZ+1.0;}       
       if (pixelRefOX[i]<0) {rkletVERT=rkletVERT+1.0;}*/              
    }
          
    /* normalize the ranks */ 
    rkletHORIZ/=npointsD*npointsD/8.0;
    rkletVERT/=npointsSquareD/8.0;
    rkletDIAG/=npointsSquareD/8.0;
        
    pixelPos=posOX+M*posOY;
    /* m + M*n */
    HORIZMAT[pixelPos]=(double) rkletHORIZ;
    VERTMAT[pixelPos] =(double) rkletVERT;
    DIAGMAT[pixelPos] =(double) rkletDIAG; 
    
    /* debugging use only
     */
    /*HORIZMAT[pixelPos] = (double) 1;
    VERTMAT[pixelPos]  = (double) 2;
    DIAGMAT[pixelPos]  = (double) 3; */    
    /*HORIZMAT[pixelPos]=(double)A[pixelPos];
    VERTMAT[pixelPos] =(double)A[pixelPos];
    DIAGMAT[pixelPos] =(double)A[pixelPos];*/
}

void computeHalFranks(int npoints, int * pixelBuffer, int * pixelIndexBuffer, double * halfRanks){
  int i, j;
  double k;
  /* halfRanks[npoints-1]=-1; */
  for (i=0;i<npoints-1;i++){
    for(j=i+1;j<npoints;j++){
      if (pixelBuffer[i]!=pixelBuffer[j])break;
    }
    if(i<--j){
     k=(double)(i+j)/2;
     for (;i<j;i++){
       halfRanks[i]=k;
     }
       halfRanks[i]=k;
    }else{
      halfRanks[i]=i;
    }
  }
  if(i==(npoints-1))halfRanks[npoints-1]=npoints-1;
}


/*
 quickSort

 This public-domain C implementation by Darel Rex Finley.

 * This function assumes it is called with valid parameters.

 * Example calls:
   quickSort(&myArray[0],5); // sorts elements 0, 1, 2, 3, and 4
   quickSort(&myArray[3],5); // sorts elements 3, 4, 5, 6, and 7
*/
void quickSort(int *arr, int elements, int *keys) {
  /* max array of 2^64 if you are using a 64 bits system */
  #define  MAX_LEVELS  64

  int  piv, beg[MAX_LEVELS], end[MAX_LEVELS], i=0, L, R, swap ;
  int  pivKey;
  beg[0]=0; end[0]=elements;
  while (i>=0) {
    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L];
      pivKey=keys[L];
      while (L<R) {
        while (arr[R]>=piv && L<R) R--; if (L<R) {arr[L]=arr[R]; keys[L]=keys[R]; L++;}
        while (arr[L]<=piv && L<R) L++; if (L<R) {arr[R]=arr[L]; keys[R]=keys[L]; R--;}
      }
      arr[L]=piv; keys[L]=pivKey; 
      beg[i+1]=L+1; end[i+1]=end[i]; end[i++]=L;
      if (end[i]-beg[i]>end[i-1]-beg[i-1]) {
        swap=beg[i]; beg[i]=beg[i-1]; beg[i-1]=swap;
        swap=end[i]; end[i]=end[i-1]; end[i-1]=swap; }}
    else {
      i--; }}
  
}
